insert into user values(101, sysdate(), 'AB');
insert into user values(102, sysdate(), 'VK');
insert into user values(103, sysdate(), 'MS');
insert into user values(104, sysdate(), 'UV');

insert into post values(1101,'My first post', 101);
insert into post values(1102,'My second post', 101);
