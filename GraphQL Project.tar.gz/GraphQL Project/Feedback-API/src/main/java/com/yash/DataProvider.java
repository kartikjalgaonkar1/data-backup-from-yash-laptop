package com.yash;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataProvider implements CommandLineRunner{

	@Autowired
	private FeedbackRepository feedbackRepository;
	
	public DataProvider() {
		// TODO Auto-generated constructor stub
	}
	
	public DataProvider(FeedbackRepository feedbackRepository) {
		super();
		this.feedbackRepository = feedbackRepository;
	}



	@Override
    @Transactional
    public void run(String... strings) {
		System.out.println("inside run");
		feedbackRepository.save(new Feedback(1, "kartik", "yash Tech", 5, "best"));
		feedbackRepository.save(new Feedback(2, "yash", "JD", 4, "good"));
		feedbackRepository.save(new Feedback(3, "Manohar", "yash Tech", 4, "better"));
		feedbackRepository.save(new Feedback(4, "Ruchi", "JD", 3, "good"));
		
	}
}
