package com.yash;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLResolver;

@Component
public class FeedbackResolver implements GraphQLResolver<Feedback> {

}
