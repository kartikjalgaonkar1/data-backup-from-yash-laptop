package com.yash.microservices.feedback;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface FeedbackRepository extends CrudRepository<Feedback, Long> {
    List<Feedback> findAllByOrderByIdDesc();
    Optional<Feedback> findById(Long id);
	Integer deleteById(Integer id);
}
