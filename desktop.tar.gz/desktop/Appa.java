import java.util.ArrayList;

public class Appa {
	//public static int list[]= {-1,8,7};
	public static int list[]= {-1,7,8,-5,4};
	//public static int list[]= {3,2,1,-1};
	//public static int list[]= {11,12,-2,-1};
	//public static int list[]= {4,5,4,3};
	//public static int list[]= {5,10,4,-1};
	
	public static void main(String[] args) {
		ArrayList<Integer> groupFormed=function(0,new ArrayList<Integer>());
		System.out.println("result: ");
		for(int i=groupFormed.size()-1;i>=0;i--)
			System.out.print(list[groupFormed.get(i)]);
	}
	private static ArrayList<Integer> function(int index,ArrayList<Integer> yetFormed) {
		//if reached to the end
		if(index==list.length) return yetFormed;
		
		ArrayList<Integer> listWithoutThisIndex=new ArrayList<>(yetFormed);
		ArrayList<Integer> groupFormedWithoutThisIndex=function(index+1,listWithoutThisIndex);
		ArrayList<Integer> bestGroupFormed=groupFormedWithoutThisIndex; //by default set group without
		
		if(isThisIndexEligibleToAddInGroup(index,yetFormed)) {
			ArrayList<Integer> listWithThisIndex=new ArrayList<>(yetFormed);
			listWithThisIndex.add(index);
			ArrayList<Integer> groupFormedWithThisIndex=function(index+1,listWithThisIndex);
			
			bestGroupFormed=findBestGroup(groupFormedWithThisIndex,groupFormedWithoutThisIndex);
		}
		
		return bestGroupFormed;
	}
	private static boolean isThisIndexEligibleToAddInGroup(int index, ArrayList<Integer> yetFormed) {
		if(list[index]<0) return false; //if -ve present at index
		
		for(Integer i:yetFormed) {
			if(i.equals(index+1) || i.equals(index-1)) return false; //Neighbor is already in the list
		}
		return true;
	}
	private static ArrayList<Integer> findBestGroup(ArrayList<Integer> group1,ArrayList<Integer> group2) {
		int sum1=sumUp(group1);
		int sum2=sumUp(group2);
		
		//simple cases
		if(sum1>sum2) return group1;
		else if(sum2>sum1) return group2;
		//complex case: both groups' sum is equal
		else {
			for(int i=group1.size()-1,j=group2.size()-1;i>=0 && j>=0;i--,j--) {// start from end of the groups
				if(list[group1.get(i)]==list[group2.get(j)]) continue; //if equal continue
				//if not equal
				if(list[group1.get(i)]> list[group2.get(j)]) return group1;
				else 										 return group2;
			}
			//both groups are same here... return anyone, doesn't matter!
			return group1;
		}
	}
	private static int sumUp(ArrayList<Integer> group) {
		int sum=0;
		for(Integer i:group) sum+=list[i];
		return sum;
	}

}
