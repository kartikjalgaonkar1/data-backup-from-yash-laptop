echo 'Starting services for capability project...'

sudo service postgresql start
echo 'postgres service started'
sudo systemctl start jenkins
echo 'jenkins service started'
sudo systemctl start sonar
echo 'sonar service started'
sudo systemctl start elasticsearch
echo 'elasticsearch service started'
sudo systemctl start logstash
echo 'logstash service started'
sudo systemctl start kibana
echo 'kibana service started'
sudo /usr/share/zookeeper/bin/zkServer.sh start-foreground &
echo 'zookeeper service started'


