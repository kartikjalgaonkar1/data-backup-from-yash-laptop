package com.yash.GraphQLCRUDSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlCrudSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphQlCrudSpringBootApplication.class, args);
	}

}
