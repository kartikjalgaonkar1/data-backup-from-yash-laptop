package com.yash.service;

import java.io.File;
import java.io.IOException;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.yash.model.Book;
import com.yash.repository.BookRepository;
import com.yash.service.datafetcher.AllBooksDataFetcher;
import com.yash.service.datafetcher.BookDataFetcher;

import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;

@Service
public class GraphQLService {

	@Value("classpath:books.graphql")
	Resource resource;
	@Autowired
	BookRepository bookRepository;
	private GraphQL graphQL;

	@Autowired
	private AllBooksDataFetcher allBooksDataFetcher;
	@Autowired
	private BookDataFetcher bookDataFetcher;

	@PostConstruct
	public void loadSchema() throws IOException {

		// save data into database
		loadDataIntoHSQL();

		File schemaFile = resource.getFile();
		TypeDefinitionRegistry definitionRegistry = new SchemaParser().parse(schemaFile);
		RuntimeWiring wiring = buildRuntimeWiring();
		GraphQLSchema schema = new SchemaGenerator().makeExecutableSchema(definitionRegistry, wiring);
		graphQL = GraphQL.newGraphQL(schema).build();

	}

	private void loadDataIntoHSQL() {
		
		Stream.of(
				new Book("1", "Java 8", "Oracle", new String[] {"James Gossling"}, "Jan 2001"),
				new Book("2", "Cloud", "Kindle", new String[] {"Chloe"}, "Jul 2017"),
				new Book("1", "History", "Board", new String[] {"ABC, EFG"}, "Jan 2001")
				).forEach(book -> bookRepository.save(book));

	}

	private RuntimeWiring buildRuntimeWiring() {
		return RuntimeWiring.newRuntimeWiring().type("Query", typeWiring -> typeWiring
				.dataFetcher("allBooks", allBooksDataFetcher).dataFetcher("book", bookDataFetcher)).build();
	}

	public GraphQL getgraphQL() {
		return graphQL;
	}
}
