package com.yash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlMutationApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphQlMutationApplication.class, args);
	}

}
