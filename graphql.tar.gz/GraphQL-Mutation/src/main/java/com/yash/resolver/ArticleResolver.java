package com.yash.resolver;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.yash.repository.CommentRepository;
import com.yash.repository.ProfileRepository;

@Component
public class ArticleResolver implements GraphQLQueryResolver {
	
	private CommentRepository commentRepository;
	private ProfileRepository profileRepository;

	public ArticleResolver(CommentRepository commentRepository, ProfileRepository profileRepository) {
		super();
		this.commentRepository = commentRepository;
		this.profileRepository = profileRepository;
	}

}
