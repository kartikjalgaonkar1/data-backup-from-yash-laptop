package com.yash.resolver;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLResolver;
import com.yash.model.Comment;
import com.yash.model.Profile;
import com.yash.repository.ProfileRepository;

@Component
public class CommentResolver implements GraphQLResolver<Comment> {
    private ProfileRepository profileRepository;

    public Profile getAuthor(Comment comment) {
    	Optional<Profile> profile = profileRepository.findById(comment.getAuthorId());
        return profile.get();
    }
}