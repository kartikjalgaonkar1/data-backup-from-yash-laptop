package com.yash.resolver;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.yash.model.Article;
import com.yash.model.Comment;
import com.yash.model.Profile;
import com.yash.repository.ArticleRepository;
import com.yash.repository.CommentRepository;
import com.yash.repository.ProfileRepository;

@Component
public class QueryResolver implements GraphQLQueryResolver {

	private ArticleRepository articleRepository;
	private ProfileRepository profileRepository;
	private CommentRepository commentRepository;

	public QueryResolver(ArticleRepository articleRepository, ProfileRepository profileRepository,
			CommentRepository commentRepository) {
		super();
		this.articleRepository = articleRepository;
		this.profileRepository = profileRepository;
		this.commentRepository = commentRepository;
	}
	
	public List<Article> getArticles(){
		return articleRepository.findAll();
	}
	
	public List<Profile> getProfiles(){
		return profileRepository.findAll();
	}
	
	public List<Comment> getComments(){
		return commentRepository.findAll();
	}
	
	public Article getArticle(Long articleId) {
		Optional<Article> article = articleRepository.findById(articleId);
		return article.get();
	}

}
