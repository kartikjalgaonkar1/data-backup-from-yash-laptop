package com.yash.graphql;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;

import graphql.GraphQLException;

@Component
public class MutationResolver implements GraphQLMutationResolver{

	@Autowired
	UserRepository repository;
	
	@Transactional
	public User createUser(String name, AuthData authData) {
		User user = new User(name, authData.getEmail(), authData.getPassword());
		return repository.save(user);
	}
	
	public SigninPayLoad signinUser(AuthData authData) throws IllegalAccessException{
		User user = repository.findByEmail(authData.getEmail());
		if(user.getPassword().equals(authData.getPassword())) {
			return new SigninPayLoad(user.getId(), user);
		}
		throw new GraphQLException("Invalid credentials");
	}
	
	
}