package com.yash.graphql;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;

@Component
public class QueryResolver implements GraphQLQueryResolver{

	@Autowired
	private UserRepository repository;
	
	public User getUser(String id) {
		return repository.findById(id);
	}
	
	public List<User> getAllUsers(){
		return repository.findAll();
	}
}
